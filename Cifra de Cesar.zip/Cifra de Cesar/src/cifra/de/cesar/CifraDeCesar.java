package cifra.de.cesar;

import java.util.Scanner;

public class CifraDeCesar {
    
    public static Scanner ler = new Scanner(System.in);
    
    public static void main(String[] args) {
        String alfabeto[] = new String[25];
        
        alfabeto[0] = "a";
        alfabeto[1] = "b";
        alfabeto[2] = "c";
        alfabeto[3] = "d";
        alfabeto[4] = "e";
        alfabeto[5] = "f";
        alfabeto[6] = "g";
        alfabeto[7] = "h";
        alfabeto[8] = "i";
        alfabeto[9] = "k";
        alfabeto[10] = "l";
        alfabeto[11] = "m";
        alfabeto[12] = "n";
        alfabeto[13] = "o";
        alfabeto[14] = "p";
        alfabeto[15] = "q";
        alfabeto[16] = "r";
        alfabeto[17] = "s";
        alfabeto[18] = "t";
        alfabeto[19] = "u";
        alfabeto[20] = "v";
        alfabeto[21] = "w";
        alfabeto[22] = "x";
        alfabeto[23] = "y";
        alfabeto[24] = "z";
        
        int n;
        
        int q;
        
        n = ler.nextInt();
        
        String senha = ler.next();
        
        char [] arraySenhaChar = senha.toCharArray();
        String arraySenhaString[] = new String[arraySenhaChar.length];
        
        for (int i = 0; i < arraySenhaString.length; i++) {
            arraySenhaString[i] = Character.toString(arraySenhaChar[i]);
            for (int j = 0; j < 25; j++) {
                q = j+n;
                if (arraySenhaString[i] == alfabeto[j]) {
                    arraySenhaString[i] = alfabeto[q];
                }
            }
        }
        
        for (int i = 0; i < arraySenhaString.length; i++) {
            System.out.print(arraySenhaString[i]);
        }
                
    }
    
}
